package com.example.a9i7itik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ClinProf extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clin_prof);

        Bundle ae = getIntent().getExtras();
        Clinicss p = (Clinicss) ae.getSerializable("cp");

        ImageView img = findViewById(R.id.pic);
        TextView name = findViewById(R.id.clinicname);
        TextView pg = findViewById(R.id.address);


        img.setImageResource(p.getImage());
        name.setText(p.getName());
        pg.setText(p.getLocation());

        Button l = findViewById(R.id.theirloca);

        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps"));
                startActivity(browserIntent);

            }
        });
        }






}