package com.example.a9i7itik;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class Doctors extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors);

        Intent drop = getIntent();

        ArrayList<Doctorss> docss = new ArrayList<>();

        Doctorss d1 = new Doctorss("Dr. Andrew Gibbins", R.drawable.empty_profile,"Cardiology","University Of California",98052308," General Consultant");
        Doctorss d2 = new Doctorss("Dr. Micheal Drew", R.drawable.empty_profile, "Neuroscience", "John Hopkins University",55884401,"Sub-speciality Consultant");
        Doctorss d3 = new Doctorss("Dr. Abduallah Al-Azemi", R.drawable.empty_profile,"Physical Therapy","Kuwait University", 72722005,"Senior specialist");
        Doctorss d4 = new Doctorss("Maryam Al-Mutairi", R.drawable.female_photo, "Physical Therapy","Kuwait University",90088384,"General specialist");
        Doctorss d5 = new Doctorss("Fatima Al-Qallaf", R.drawable.female_photo,"Dentistry","University Of Manchester",54453003,"Attending physician");
        Doctorss d6 = new Doctorss("Khaled Al-Otaibi", R.drawable.empty_profile,"Nursing", "University Of Boston",98569830,"Resident");

        docss.add(d1);
        docss.add(d2);
        docss.add(d3);
        docss.add(d4);
        docss.add(d5);
        docss.add(d6);

        RecyclerView rv = findViewById(R.id.docsrecycle);
        rv.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));

        rv.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);

        DAdapt pa = new DAdapt(docss,this);
        rv.setAdapter(pa);
    }
}