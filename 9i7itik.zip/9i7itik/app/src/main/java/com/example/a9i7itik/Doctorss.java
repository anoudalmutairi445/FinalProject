package com.example.a9i7itik;

import java.io.Serializable;

public class Doctorss implements Serializable {
    private String name;
    private int image;
    private String major;
    private String jobTitle;
    private String university;
    private int phonenum;

    public Doctorss(String name, int image, String major, String university,int phonenum, String jobTitle) {
        this.name = name;
        this.image = image;
        this.major = major;
        this.university = university;
        this.phonenum = phonenum;
        this.jobTitle = jobTitle;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public int getPhonenum() {
        return phonenum;
    }
    public void setPhonenum(int phonenum) {
        this.phonenum = phonenum;
    }

    public String getjobTitle() {
        return jobTitle;
    }

    public void setjobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }
}

