package com.example.a9i7itik;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class Clinics extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clinics);



        ArrayList<Clinicss> clicss = new ArrayList<>();

        Clinicss c1 = new Clinicss("Salmiya Clinic", R.drawable.empty_profile,"Salmiya");
        Clinicss c2 = new Clinicss("Yarmouk Clinic", R.drawable.empty_profile,"Yarmouk");
        Clinicss c3 = new Clinicss("Jouri Clinic", R.drawable.empty_profile,"Salmiya");
        Clinicss c4 = new Clinicss("Kuwait Co-op Clinic", R.drawable.empty_profile,"Kuwait City");

        clicss.add(c1);
        clicss.add(c2);
        clicss.add(c3);
        clicss.add(c4);

        RecyclerView rs = findViewById(R.id.clicrecycle);
        rs.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));

        rs.setHasFixedSize(true);
        RecyclerView.LayoutManager dm = new LinearLayoutManager(this);
        rs.setLayoutManager(dm);


        CAdapt ca = new CAdapt(clicss,this);
        rs.setAdapter(ca);





    }
}