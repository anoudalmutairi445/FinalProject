package com.example.a9i7itik;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DocProf extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_prof);

        Bundle aie = getIntent().getExtras();
        Doctorss p = (Doctorss) aie.getSerializable("dp");

        ImageView img = findViewById(R.id.pic);
        TextView name = findViewById(R.id.name);
        TextView pg = findViewById(R.id.majors);
        TextView rdd = findViewById(R.id.university);
        TextView pn = findViewById(R.id.phonenumm);
        TextView jt =  findViewById(R.id.jobtitle);


        img.setImageResource(p.getImage());
        name.setText(p.getName());
        pg.setText(p.getMajor()+"");
        rdd.setText(p.getUniversity()+"");
        pn.setText(p.getPhonenum()+"");
        jt.setText(p.getjobTitle());


    }
}