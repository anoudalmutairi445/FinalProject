package com.example.a9i7itik;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CAdapt extends RecyclerView.Adapter {

    ArrayList<Clinicss> cArray;
    Context context;

    public CAdapt(ArrayList<Clinicss> cArray, Context context) {
        this.cArray = cArray;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.clinic_item, parent, false);
        CAdapt.ViewHolder vh = new CAdapt.ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((CAdapt.ViewHolder) holder).cimg.setImageResource(cArray.get(position).getImage());
        ((CAdapt.ViewHolder) holder).cname.setText(cArray.get(position).getName());
        ((CAdapt.ViewHolder) holder).clocation.setText(cArray.get(position).getLocation());
        ((CAdapt.ViewHolder) holder).vieww.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, ClinProf.class);
                i.putExtra("cp", cArray.get(position));
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return cArray.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView cimg;
        public TextView cname;
        public TextView clocation;
        public View vieww;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            vieww = itemView;
            cimg = itemView.findViewById(R.id.clincimg);
            cname = itemView.findViewById(R.id.clinicname);
            clocation = itemView.findViewById(R.id.location);
        }


    }
}