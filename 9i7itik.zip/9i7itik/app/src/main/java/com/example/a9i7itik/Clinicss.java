package com.example.a9i7itik;

import java.io.Serializable;

public class Clinicss implements Serializable {
    private String name;
    private int image;
    private String Location;


    public Clinicss(String name, int image, String location) {
        this.name = name;
        this.image = image;
        Location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }
}
