package com.example.a9i7itik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        getIntent();

        TextView name = findViewById(R.id.flname);
        TextView age = findViewById(R.id.agee);
        TextView medv = findViewById(R.id.medicalcon);
        TextView lname = findViewById(R.id.lastname);

        Bundle port = getIntent().getExtras();
        String myL = port.getString("ln");
        String myr = port.getString("age");
        String myh = port.getString("fn");
        String mys = port.getString("med");

        name.setText(myL);
        age.setText(myr);
        medv.setText(mys);
        lname.setText(myh);

        Button back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent n = new Intent(Profile.this, MainActivity.class);
                startActivity(n);
            }
        });





    }
}