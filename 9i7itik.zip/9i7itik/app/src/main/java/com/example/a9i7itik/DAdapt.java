package com.example.a9i7itik;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DAdapt extends RecyclerView.Adapter {

    ArrayList<Doctorss> pArray;
    Context context;

    public DAdapt(ArrayList<Doctorss> pArray, Context context) {
        this.pArray = pArray;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.doc_item,parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ViewHolder) holder).docimg.setImageResource(pArray.get(position).getImage());
        ((ViewHolder) holder).name.setText(pArray.get(position).getName());
        ((ViewHolder) holder).major.setText(pArray.get(position).getMajor());
        ((ViewHolder) holder).view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, DocProf.class);
                i.putExtra("dp",pArray.get(position));
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return pArray.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView docimg;
        public TextView name;
        public TextView major;
        public View view;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            docimg = itemView.findViewById(R.id.docimg);
            name = itemView.findViewById(R.id.docname);
            major = itemView.findViewById(R.id.major);

        }
    }
}
