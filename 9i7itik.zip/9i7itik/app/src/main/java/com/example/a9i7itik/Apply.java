package com.example.a9i7itik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Apply extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply);

        final EditText s = findViewById(R.id.firstn);
        final EditText b = findViewById(R.id.lastn);
        final EditText a = findViewById(R.id.mcon);
        final EditText g = findViewById(R.id.age);
        Button d = findViewById(R.id.done);

        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ln = b.getText().toString();
                String age = g.getText().toString();
                String fn = s.getText().toString();
                String med = a.getText().toString();

                Intent x = new Intent( Apply.this , Profile.class);
                x.putExtra("ln", ln);
                x.putExtra("age", age);
                x.putExtra("fn", fn);
                x.putExtra("med", med);

                startActivity(x);
            }
        });
    }
}